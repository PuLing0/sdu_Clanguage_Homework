#include "ticket.h"

ticket::ticket()
{

}
