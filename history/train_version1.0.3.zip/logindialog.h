#ifndef LOGINDIALOG_H
#define LOGINDIALOG_H

#include <QString>


class LoginDialog
{
public:
    bool LoginUser(QString account , QString password);//用于进行登录的操作
public:
    LoginDialog();//默认构造函数
};

#endif // LOGINDIALOG_H
