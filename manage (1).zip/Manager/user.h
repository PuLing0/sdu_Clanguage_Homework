#ifndef USER_H
#define USER_H
#include<QString>
#include<vector>
class user
{
public:
    user();
    QString name;
    QString id;
    QString passwd;
};

#endif // USER_H
