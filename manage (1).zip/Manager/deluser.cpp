#include "deluser.h"
#include "ui_deluser.h"

deluser::deluser(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::deluser)
{
    ui->setupUi(this);
}

deluser::~deluser()
{
    delete ui;
}
